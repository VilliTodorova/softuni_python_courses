from project.knight import Knight


class DarkKnight(Knight):
    def __init__(self, name, level):
        Knight.__init__(self, name, level)
