from project.food import Food
from project.fruit import Fruit

fruit = Fruit("banana", "2024-27-06")
food = Food("2025-01-01")

print(fruit)
