from project.dog import Dog
from project.animal import Animal

dog = Dog()
print(dog.bark())
print(dog.eat())
